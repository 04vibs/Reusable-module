import { HighlightSearchedTextPipe } from './highlight-searched-text.pipe';

describe('HighlightSearchedTextPipe', () => {
  it('create an instance', () => {
    const pipe = new HighlightSearchedTextPipe();
    expect(pipe).toBeTruthy();
  });
});
