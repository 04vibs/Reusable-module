
export interface IUser {
    id: any;
    name: any;
    email: any;
    phoneno: any;

}
