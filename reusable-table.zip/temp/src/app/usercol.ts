export const Coldata = [
      { attribute: 'id', value: 'ID'},
      { attribute: 'name', value: 'Name'},
      { attribute: 'username', value: 'UserName'},
      { attribute: 'email', value: 'email'},
];
